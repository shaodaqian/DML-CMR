from __future__ import annotations
from typing import Dict, Any, Optional
import torch
from torch import nn
import logging
from pathlib import Path

from .model import Treatment,train_treatment,train_Ymodel,Ymodel,Response,train_response
from .utils import ResponseDataset

import numpy as np
from src.data.ate import generate_train_data_ate, generate_test_data_ate, get_preprocessor_ate
from src.data.ate.data_class import PVTrainDataSetTorch, PVTestDataSetTorch, split_train_data, PVTrainDataSet, \
    PVTestDataSet

def dml_cpl_experiments(data_config: Dict[str, Any], model_param: Dict[str, Any],
                     one_mdl_dump_dir: Path, random_seed: int = 42, verbose: int = 0):
    dump_dir = one_mdl_dump_dir.joinpath(f"{random_seed}")

    train_data_org = generate_train_data_ate(data_config=data_config, rand_seed=random_seed)
    test_data_org = generate_test_data_ate(data_config=data_config)

    preprocessor = get_preprocessor_ate(data_config.get("preprocess", "Identity"))
    train_data = preprocessor.preprocess_for_train(train_data_org)
    test_data = preprocessor.preprocess_for_test_input(test_data_org)


    torch.manual_seed(random_seed)

    n_components = 10
    loss = 'mixture_of_gaussians'

    hidden = [128, 64, 32]

    dropout_rate = 0.05

    w_decay = 0.001
    repeats = 1
    lr = 0.0002
    epochs= 200
    batch_size = 100

    # treatment: np.ndarray
    # treatment_proxy: np.ndarray
    # outcome_proxy: np.ndarray
    # outcome: np.ndarray
    # backdoor: Optional[np.ndarray]

    # z: treatment_proxy
    # t: outcome proxy
    # x: treatment
    # y: outcome


    # train_data = ResponseDataset(z,x,t,y)
    # train_data = z, x, t, y

    train_dataset = ResponseDataset(train_data.treatment_proxy, train_data.treatment, train_data.outcome_proxy, train_data.outcome)
    valid_data = ResponseDataset(test_data.treatment_proxy, test_data.treatment, test_data.outcome_proxy, test_data.outcome)

    treat_dim = train_data.treatment_proxy.shape[-1] + train_data.treatment.shape[-1]



    treatment_model = Treatment(treat_dim, hidden, dropout_rate, n_components)
    treatment_model = train_treatment(treatment_model, train_dataset, valid_data, batch_size, loss, epochs, lr, w_decay)
    treatment_model.eval()

    # epochs = 500
    Y_model = Ymodel(treat_dim, hidden, dropout_rate)
    Y_model = train_Ymodel(Y_model, train_dataset, valid_data, batch_size, epochs, lr, w_decay)
    Y_model.eval()

    # x, z, t, y, g_true = datafunction(int(n), 2)
    # epochs=500
    # batch_size=100
    n_samples = 1
    resp_dim = x.shape[-1] + t.shape[-1]
    dml = False
    standard_response = Response(resp_dim, hidden, 0)
    standard_response = train_response(standard_response, treatment_model, Y_model, train_dataset, valid_data, dml,
                                       batch_size, epochs, lr, w_decay, n_samples)
    standard_response.eval()

    dml = True
    dml1_response = Response(resp_dim, hidden, 0)
    dml1_response = train_response(dml1_response, treatment_model, Y_model, train_dataset, valid_data, dml, batch_size,
                                   epochs, lr, w_decay, n_samples)
    dml1_response.eval()



    test_data_t = PVTestDataSetTorch.from_numpy(test_data)
    test_data_t = test_data_t.to_gpu()

    standard_response(torch.tensor(x).to(device), torch.tensor(t).to(device))



    pred: np.ndarray = mdl.predict_t(test_data_t.treatment).data.cpu().numpy()
    pred = preprocessor.postprocess_for_prediction(pred)
    oos_loss = 0.0
    if test_data.structural is not None:
        oos_loss: float = np.mean((pred - test_data_org.structural) ** 2)
        if data_config["name"] in ["kpv", "deaner"]:
            oos_loss = np.mean(np.abs(pred - test_data_org.structural))
    np.savetxt(one_mdl_dump_dir.joinpath(f"{random_seed}.pred.txt"), pred)
    return oos_loss
